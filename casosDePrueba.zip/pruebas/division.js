function division(a, b) {
    return a / b;
  }
  module.exports = division;