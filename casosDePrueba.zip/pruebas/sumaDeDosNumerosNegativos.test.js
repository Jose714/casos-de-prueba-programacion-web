const sum = require('./suma');

test('adds -1 +(-2) su resultado debe ser negativo', () => {
  expect(sum(-1, -2)).toBe(-3);
});