function potencia(a, b) {
    return Math.pow(a,b);
  }
  module.exports = potencia;