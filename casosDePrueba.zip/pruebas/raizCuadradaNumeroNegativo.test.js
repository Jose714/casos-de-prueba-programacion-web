const raizCuadrada = require('./raizCudrada');

test('no se puede realizar la raiz cuadrada de un numero negativo', () => {
  expect(raizCuadrada(-9)).toBe(NaN);
});