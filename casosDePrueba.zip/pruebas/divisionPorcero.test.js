const division = require('./division');

test('adds 2 / 2 to equal no se puede realizar', () => {
  expect(division(2, 0)).toBe(Infinity);
});