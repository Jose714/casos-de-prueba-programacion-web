const potencia = require('./potencia');

test('una base negativa al cudrado debe dar un numero positivo', () => {
  expect(potencia(-2, 2)).toBe(4);
});