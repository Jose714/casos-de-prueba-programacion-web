const potencia = require('./potencia');

test('adds 2 ^ 2 to equal 4', () => {
  expect(potencia(2, 2)).toBe(4);
});