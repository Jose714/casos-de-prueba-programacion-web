function raizCuadrda(a) {
    return Math.sqrt(a);
  }
  module.exports = raizCuadrda;