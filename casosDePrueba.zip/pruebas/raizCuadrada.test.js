const raizCuadrada = require('./raizCudrada');

test('adds 9 to equal 3', () => {
  expect(raizCuadrada(9)).toBe(3);
});