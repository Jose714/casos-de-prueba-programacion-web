const sum = require('./division');

test('adds 2 / 2 to equal 1', () => {
  expect(sum(2, 2)).toBe(1);
});